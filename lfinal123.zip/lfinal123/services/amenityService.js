import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getAllAmenities = async (req, res) => {
  try {
    const amenities = await prisma.amenity.findMany();
    res.json(amenities);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching amenities" });
  }
};

export const createAmenity = async (req, res) => {
  try {
    const { name } = req.body;
    const newAmenity = await prisma.amenity.create({
      data: { name },
    });
    res.status(201).json(newAmenity);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while creating amenity" });
  }
};

export const getAmenityById = async (req, res) => {
  try {
    const { id } = req.params;
    const amenity = await prisma.amenity.findUnique({ where: { id } });
    if (amenity) {
      res.json(amenity);
    } else {
      res.status(404).json({ error: "Amenity not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching amenity" });
  }
};

export const updateAmenity = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    const updatedAmenity = await prisma.amenity.update({
      where: { id },
      data: { name },
    });
    res.json(updatedAmenity);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while updating amenity" });
  }
};

export const deleteAmenity = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.amenity.delete({ where: { id } });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: "An error occurred while deleting amenity" });
  }
};

export const searchAmenities = async (req, res) => {
  try {
    const { name } = req.query;
    const filters = {};

    if (name) filters.name = { contains: name };

    const amenities = await prisma.amenity.findMany({
      where: filters,
    });

    if (amenities.length === 0) {
      res.status(404).json({ error: "Amenity not found" });
    } else {
      res.json(amenities);
    }
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while searching amenities" });
  }
};

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getAllReviews = async (req, res) => {
  try {
    const reviews = await prisma.review.findMany();
    res.json(reviews);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching reviews" });
  }
};

export const createReview = async (req, res) => {
  try {
    const { rating, comment, userId, propertyId } = req.body;
    const newReview = await prisma.review.create({
      data: { rating, comment, userId, propertyId },
    });
    res.status(201).json(newReview);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while creating review" });
  }
};

export const getReviewById = async (req, res) => {
  try {
    const { id } = req.params;
    const review = await prisma.review.findUnique({ where: { id } });
    if (review) {
      res.json(review);
    } else {
      res.status(404).json({ error: "Review not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "An error occurred while fetching review" });
  }
};

export const updateReview = async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, comment, userId, propertyId } = req.body;
    const updatedReview = await prisma.review.update({
      where: { id },
      data: { rating, comment, userId, propertyId },
    });
    res.json(updatedReview);
  } catch (error) {
    res.status(500).json({ error: "An error occurred while updating review" });
  }
};

export const deleteReview = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.review.delete({ where: { id } });
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: "An error occurred while deleting review" });
  }
};

export const searchReviews = async (req, res) => {
  try {
    const { comment, rating } = req.query;
    const filters = {};
    if (comment) filters.comment = { contains: comment };
    if (rating) filters.rating = { equals: parseInt(rating) };

    const reviews = await prisma.review.findMany({ where: filters });
    if (reviews.length === 0) {
      res.status(404).json({ error: "Review not found" });
    } else {
      res.json(reviews);
    }
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while searching reviews" });
  }
};

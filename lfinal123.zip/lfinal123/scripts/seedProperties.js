import pkg from "@prisma/client";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
const { PrismaClient } = pkg;
const prisma = new PrismaClient();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const seedProperties = async () => {
  const dataPath = path.join(__dirname, "../data/properties.json");
  const propertiesData = JSON.parse(fs.readFileSync(dataPath, "utf8"));

  for (const property of propertiesData.properties) {
    await prisma.property.upsert({
      where: { id: property.id },
      update: {
        title: property.title,
        description: property.description,
        location: property.location,
        pricePerNight: parseFloat(property.pricePerNight),
        bedroomCount: property.bedroomCount,
        bathRoomCount: property.bathRoomCount,
        maxGuestCount: property.maxGuestCount,
        hostId: property.hostId,
        rating: property.rating,
      },
      create: {
        id: property.id,
        title: property.title,
        description: property.description,
        location: property.location,
        pricePerNight: parseFloat(property.pricePerNight),
        bedroomCount: property.bedroomCount,
        bathRoomCount: property.bathRoomCount,
        maxGuestCount: property.maxGuestCount,
        hostId: property.hostId,
        rating: property.rating,
      },
    });
  }
};

const main = async () => {
  try {
    await seedProperties();
    console.log("Properties seeded successfully.");
  } catch (error) {
    console.error("Error seeding properties:", error);
  } finally {
    await prisma.$disconnect();
  }
};

main();

import pkg from "@prisma/client";
import fs from "fs";
import { fileURLToPath } from "url";
import path from "path";
const { PrismaClient } = pkg;
const prisma = new PrismaClient();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function seedAmenities() {
  const dataPath = path.join(__dirname, "../data/amenities.json");
  const amenitiesData = JSON.parse(
    fs.readFileSync(dataPath, "utf-8")
  ).amenities;

  for (const amenity of amenitiesData) {
    await prisma.amenity.upsert({
      where: { id: amenity.id },
      update: { ...amenity },
      create: { ...amenity },
    });
  }
}

seedAmenities()
  .then(() => {
    console.log("Seeding completed.");
  })
  .catch((error) => {
    console.error("Error seeding amenities:", error);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

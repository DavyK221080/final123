import pkg from "@prisma/client";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
const { PrismaClient } = pkg;
const prisma = new PrismaClient();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const seedHosts = async () => {
  const dataPath = path.join(__dirname, "../data/hosts.json");
  const hostsData = JSON.parse(fs.readFileSync(dataPath, "utf8"));

  for (const host of hostsData.hosts) {
    await prisma.host.upsert({
      where: { id: host.id },
      update: host,
      create: host,
    });
  }
};

const main = async () => {
  try {
    await seedHosts();
    console.log("Hosts seeded successfully.");
  } catch (error) {
    console.error("Error seeding hosts:", error);
  } finally {
    await prisma.$disconnect();
  }
};

main();

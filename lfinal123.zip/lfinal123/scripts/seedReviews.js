import { PrismaClient } from "@prisma/client";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const prisma = new PrismaClient();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function seedReviews() {
  const dataPath = path.join(__dirname, "../data/reviews.json");
  const reviews = JSON.parse(fs.readFileSync(dataPath, "utf-8")).reviews;

  for (const review of reviews) {
    await prisma.review.upsert({
      where: { id: review.id },
      update: review,
      create: review,
    });
  }
}

seedReviews()
  .then(() => {
    console.log("Reviews seeded successfully.");
  })
  .catch((e) => {
    console.error("Error seeding reviews:", e);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

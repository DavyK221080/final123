import { PrismaClient } from "@prisma/client";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const prisma = new PrismaClient();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function seedBookings() {
  const dataPath = path.join(__dirname, "../data/bookings.json");
  const bookings = JSON.parse(fs.readFileSync(dataPath, "utf-8")).bookings;

  for (const booking of bookings) {
    await prisma.booking.upsert({
      where: { id: booking.id },
      update: booking,
      create: booking,
    });
  }
}

seedBookings()
  .then(() => {
    console.log("Bookings seeded successfully.");
  })
  .catch((e) => {
    console.error("Error seeding bookings:", e);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

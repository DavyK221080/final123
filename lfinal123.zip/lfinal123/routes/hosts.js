import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllHosts,
  createHost,
  getHostById,
  updateHost,
  deleteHost,
  searchHosts,
} from "../services/hostService.js";

const router = express.Router();

router.get("/", authenticate, getAllHosts);
router.post("/", authenticate, createHost);
router.get("/search", authenticate, searchHosts);
router.get("/:id", authenticate, getHostById);
router.put("/:id", authenticate, updateHost);
router.delete("/:id", authenticate, deleteHost);

export default router;

import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import users from "./routes/users.js";
import hosts from "./routes/hosts.js";
import properties from "./routes/properties.js";
import amenities from "./routes/amenities.js";
import bookings from "./routes/bookings.js";
import reviews from "./routes/reviews.js";
import authRouter from "./routes/auth.js";
import * as Sentry from "@sentry/node";
import loggingMiddleware from "./middleware/loggingMiddleware.js";
import errorHandler from "./middleware/errorHandler.js";

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(loggingMiddleware);

// Routes
app.use("/users", users);
app.use("/hosts", hosts);
app.use("/properties", properties);
app.use("/amenities", amenities);
app.use("/bookings", bookings);
app.use("/reviews", reviews);
app.use("/auth", authRouter);

app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
